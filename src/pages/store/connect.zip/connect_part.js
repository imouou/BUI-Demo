﻿loader.define(function (require, exports, module) {


    var bs = bui.store({
        el: `#${module.id}`,
        scope: "page1", // 用于区分公共数据及当前数据的唯一值
        data: {
            arr: [],
            other: []
        },
        // log: true,
        templates: {
            tplA: function (data) {
                var html = "";
                data.forEach(function (item, index) {
                    html += `<li class="bui-btn">${item}</li>`;
                })
                return html;
            }
        },
        mounted: function () {
            // this.arr.push("111")
        }
    })


    // 关联1: 关联相同字段
    // bs.connect(bs2);

    // 关联2: 关联到不同字段
    // bs.connect(bs2, "attrs", "props");


    // 关联3: 关联到根路径
    // bs.connect(bs2, "attrs", "");

    return bs;
})