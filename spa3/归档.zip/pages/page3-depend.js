define(function (p,a,module) {
    console.log("page3 depend was done")
    
    module.exports =  {
        "test3":"page3-depend"
    }

})

